#include <bits/stdc++.h>
#include "bai3.h"

using namespace std;

int main() {
    ThoiGian t1(11, 11, 11); // Thời gian 11h 11m 11s
    ThoiGian t2(2, 56, 37); // Thời gian 2h 56m 37s

    cin>>t1;
    cin>>t2;
    // Thực hiện các phép toán
    ThoiGian tong = t1 + t2;
    ThoiGian hieu = t1 - t2;

    cout << "Tong: " << tong << endl;
    cout << "Hieu: " << hieu << endl;

    // Kiểm tra tăng, giảm
    ++t1;
    cout << "t1 sau khi ++: " << t1 << endl;

    --t2;
    cout << "t2 sau khi --: " << t2 << endl;

    // So sánh
    if (t1 > t2) {
        cout << "t1 lon hon t2" << endl;
    } else {
        cout << "t1 khong lon hon t2" << endl;
    }

    return 0;
}

