#include <iostream>
#include "bai2.h"

int main() {
    Complex a, b;

    // Nhập hai số phức
    cout << "Nhap so phuc a:\n";
    cin >> a;
    cout << "Nhap so phuc b:\n";
    cin >> b;

    // Thực hiện phép toán
    Complex tong = a + b;
    Complex hieu = a - b;
    Complex tich = a * b;
    Complex thuong = a / b;

    // Xuất kết quả
    cout << "Tong: " << tong << endl;
    cout << "Hieu: " << hieu << endl;
    cout << "Tich: " << tich << endl;
    cout << "Thuong: " << thuong << endl;

    // sosanh
    if(a==b) cout<<"Hai so phuc nay bang nhau"<<endl;
    else cout<<"Hai so phuc nay khac nhau"<<endl;
    return 0;
}
