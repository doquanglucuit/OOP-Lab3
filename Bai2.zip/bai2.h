#include <bits/stdc++.h>
using namespace std;

class Complex {
private:
    double real;
    double imag;
public:
    Complex(); // Khởi tạo mặc định
    Complex(double x, double y); // Khởi tạo với tham số

    // Toán tử
    Complex operator + (const Complex &oth);
    Complex operator - (const Complex &oth);
    Complex operator * (const Complex &oth);
    Complex operator / (const Complex &oth);

    bool operator == (const Complex &oth);
    bool operator != (const Complex &oth);

    // Hàm bạn bè
    friend istream& operator>>(istream &in, Complex &b);
    friend ostream& operator<<(ostream& os, const Complex &oth);
};


