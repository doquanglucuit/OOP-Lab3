#include "bai2.h"

// Hàm khởi tạo mặc định
Complex::Complex() : real(0), imag(0) {}

// Hàm khởi tạo với tham số
Complex::Complex(double x, double y) : real(x), imag(y) {}

// Định nghĩa các toán tử
Complex Complex::operator + (const Complex &oth) {
    return Complex(real + oth.real, imag + oth.imag);
}
Complex Complex::operator - (const Complex &oth) {
    return Complex(real - oth.real, imag - oth.imag);
}
Complex Complex::operator * (const Complex &oth) {
    return Complex(real * oth.real - imag * oth.imag, real * oth.imag + imag * oth.real);
}
Complex Complex::operator / (const Complex &oth) {
    double mau = oth.real * oth.real + oth.imag * oth.imag;
    return Complex((real * oth.real + imag * oth.imag) / mau, (imag * oth.real - real * oth.imag) / mau);
}

bool Complex::operator == (const Complex &oth) {
    return (real == oth.real) && (imag == oth.imag);
}
bool Complex::operator != (const Complex &oth) {
    return !(*this == oth);
}

// Định nghĩa hàm bạn bè
istream& operator>>(istream &in, Complex &oth) {
    cout << "Nhap phan thuc: ";
    in >> oth.real;
    cout << "Nhap phan ao: ";
    in >> oth.imag;
    return in;
}

ostream& operator<<(ostream& os, const Complex &oth) {
    os << oth.real << (oth.imag >= 0 ? "+" : "") << oth.imag << "i";
    return os;
}

