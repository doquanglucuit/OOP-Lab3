#include <bits/stdc++.h>
#include "bai1.h"

int main() {
    Fraction a, b;

    // Nhập hai số phức
    cout << "Nhap phan so a:\n";
    cin >> a;
    cout << "Nhap phan so b:\n";
    cin >> b;

    // Thực hiện phép toán
    Fraction tong = a + b;
    Fraction hieu = a - b;
    Fraction tich = a * b;
    Fraction thuong = a / b;

    // Xuất kết quả
    cout << "Tong: " << tong << endl;
    cout << "Hieu: " << hieu << endl;
    cout << "Tich: " << tich << endl;
    cout << "Thuong: " << thuong << endl;

    //sosanh
    if(a == b) cout<<"Hai phan so nay bang nhau"<<endl;
    if(a != b) cout<<"Hai phan so nay khac nhau"<<endl;
    if(a < b) cout<<"Phan so thu nhat be hon"<<endl;
    if(a > b) cout<<"Phan so thu nhat lon hon"<<endl;

    return 0;
}

