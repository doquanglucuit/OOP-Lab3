#include<bits/stdc++.h>
#include "bai1.h"

Fraction::Fraction(int x, int y) : tu(x), mau(y) {}

Fraction Fraction::operator + (const Fraction &oth) {
    Fraction c;
    c.tu =  tu * oth.mau + mau * oth.tu;
    c.mau = mau *oth.mau;
    int g =__gcd(c.tu,c.mau);
    c.tu /=g;
    c.mau /=g;
    return Fraction(c.tu, c.mau);
}
Fraction Fraction::operator - (const Fraction &oth) {
    Fraction c;
    c.tu= tu * oth.mau - mau * oth.tu;
    c.mau=mau*oth.mau;
    int gcd=__gcd(c.tu,c.mau);
    c.tu/=gcd;
    c.mau/=gcd;
    return Fraction(c.tu, c.mau);
}
Fraction Fraction::operator * (const Fraction &oth) {
    Fraction c;
    c.tu= tu * oth.tu;
    c.mau=mau*oth.mau;
    int gcd=__gcd(c.tu,c.mau);
    c.tu/=gcd;
    c.mau/=gcd;
    return Fraction(c.tu, c.mau);
}
Fraction Fraction::operator / (const Fraction &oth) {
    Fraction c;
    c.tu= tu * oth.mau;
    c.mau=mau*oth.tu;
    int gcd=__gcd(c.tu,c.mau);
    c.tu/=gcd;
    c.mau/=gcd;
    return Fraction(c.tu, c.mau);
}

bool Fraction::operator == (const Fraction &oth) {
    return (tu*oth.mau)==(mau*oth.tu);
}
bool Fraction::operator != (const Fraction &oth) {
    return !(*this == oth);
}

bool Fraction::operator > (const Fraction &oth){
    return (tu*oth.mau) > (mau*oth.tu);
}


bool Fraction::operator < (const Fraction &oth){
    return (tu*oth.mau) < (mau*oth.tu);
}


bool Fraction::operator >= (const Fraction &oth){
    return (tu*oth.mau) >= (mau*oth.tu);
}

bool Fraction::operator <= (const Fraction &oth){
    return (tu*oth.mau) <=(mau*oth.tu);
}

istream& operator>>(istream &in, Fraction &oth) {
    cout << "Nhap tu: ";
    in >> oth.tu;
    cout << "Nhap mau: ";
    in >> oth.mau;
    return in;
}

ostream& operator<<(ostream& os, const Fraction &oth) {
    os << oth.tu << "/" << oth.mau;
    return os;
}


