#include <iostream>
using namespace std;

class Fraction {
private:
    int tu;
    int mau;
public:
    Fraction()  {}; // Khởi tạo mặc định
    Fraction (int x, int y); // Khởi tạo với tham số

    // Toán tử
    Fraction operator + (const Fraction &oth);
    Fraction operator - (const Fraction &oth);
    Fraction operator * (const Fraction &oth);
    Fraction operator / (const Fraction &oth);

    bool operator == (const Fraction &oth);
    bool operator != (const Fraction &oth);
    bool operator >= (const Fraction &oth);
    bool operator <= (const Fraction &oth);
    bool operator < (const Fraction &oth);
    bool operator > (const Fraction &oth);

    // Hàm bạn bè
    friend istream& operator >>(istream &in, Fraction &b);
    friend ostream& operator <<(ostream& os, const Fraction &oth);
};

