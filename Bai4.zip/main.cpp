#include<bits/stdc++.h>
#include "bai4.h"

int main() {
    NgayThangNam D1, D2;

    cout << "Nhap Ngay 1:" << endl;
    cin >> D1;

    cout << "Nhap Ngay 2:" << endl;
    cin >> D2;

    cout << "D1: " << D1 << endl;
    cout << "D2: " << D2 << endl;
      if (D1 < D2) {
        cout << "Ngay 1 be hon ngay 2" << endl;
    } else if(D1> D2){
        cout << "Ngay 1 lon hon ngay 2" << endl;
    }
    else if(D1 == D2){
        cout<< "Ngay 1 bang ngay 2" <<endl;
    }
    D1 = D1 + 34;
    cout << "Ngay 1 sau khi cong 34 ngay: " << D1 << endl;

    D2 = D2 - 16;
    cout << "Ngay 2 sau khi tru 16 ngay: " << D2 << endl;

    ++D1;
    cout << "Ngay 1 sau khi cong +1 ngay: " << D1 << endl;

    --D2;
    cout << "Ngay 2 sau khi tru -1 ngay: " << D2 << endl;


    return 0;
}
